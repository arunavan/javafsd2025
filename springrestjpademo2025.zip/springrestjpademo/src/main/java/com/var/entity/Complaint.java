package com.var.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="verizoncomplaint")
public class Complaint {
	@Id
	
	
	Integer id;
//	@Column(name="status")
	String status;
	//@Column(name="complaint_date")
	LocalDate complaintDate;

}
