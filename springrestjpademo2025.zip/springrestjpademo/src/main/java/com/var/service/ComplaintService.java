package com.var.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.var.entity.Complaint;
import com.var.repository.ComplaintRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ComplaintService {
	@Autowired
	ComplaintRepository complaintRepository;
	//@Transactional
	public void addComplaint(Complaint complaint) {
		complaintRepository.save(complaint);
	}
	

}
