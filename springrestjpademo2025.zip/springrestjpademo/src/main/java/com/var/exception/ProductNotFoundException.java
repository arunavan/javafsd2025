package com.var.exception;

public class ProductNotFoundException extends RuntimeException {

	public ProductNotFoundException() {
		//super(msg);
	}

}
