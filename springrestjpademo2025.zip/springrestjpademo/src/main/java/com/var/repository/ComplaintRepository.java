package com.var.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.var.entity.Complaint;

@Repository  // Repository   -> CrudRepository -> PagingandSortingRepository ->JPARedpositoty
public interface ComplaintRepository  extends CrudRepository<Complaint,Integer>{
	// save, findById(), findAll,deleteById,...

}
