package com.example.dockerspringdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerspringdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
